package com.example.dice

class Dice {
    var sides=6
    fun roll():Int{
        var r_no:Int=(1..sides).random()
        return r_no
    }

}