package com.example.dice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    lateinit var iv_dice: ImageView
    lateinit var btn_letsroll: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        iv_dice=findViewById(R.id.iv_dice)
        btn_letsroll=findViewById(R.id.btn_letsroll)
        var img=R.drawable.dice_1
        var my_dice=Dice()
        fun after_roll(){

            img=when(my_dice.roll()){
                1->R.drawable.dice_1
                2->R.drawable.dice_2
                3->R.drawable.dice_3
                4->R.drawable.dice_4
                5->R.drawable.dice_5
                else->R.drawable.dice_6

            }
            iv_dice.setImageResource(img)

        }
        btn_letsroll.setOnClickListener {
            after_roll()

        }
        iv_dice.contentDescription=(my_dice.roll()).toString()

    }
}